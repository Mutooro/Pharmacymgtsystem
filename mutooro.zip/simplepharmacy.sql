-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 30, 2023 at 08:29 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `simplepharmacy`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `staff_id` varchar(255) NOT NULL,
  `postal_address` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`first_name`, `last_name`, `staff_id`, `postal_address`, `phone`, `email`, `admin_id`, `username`, `password`, `date`) VALUES
('Nzoghu', 'William', 'SD01', 'Kampala', '0707064552', 'william@ask.pham', 2, 'William', '$2y$10$ozvpJzi53rha.iw7rHmNHeUipIMoxc.djZzhlsirwXE99gvJXvMyK', '2023-08-10 13:27:45');

-- --------------------------------------------------------

--
-- Table structure for table `on_hold`
--

CREATE TABLE `on_hold` (
  `id` int(11) NOT NULL,
  `invoice_number` varchar(13) NOT NULL,
  `medicine_name` varchar(255) NOT NULL,
  `category` varchar(255) NOT NULL,
  `expire_date` date NOT NULL,
  `qty` bigint(11) NOT NULL,
  `type` varchar(10) NOT NULL,
  `cost` bigint(11) NOT NULL,
  `amount` bigint(11) NOT NULL,
  `profit_amount` bigint(11) NOT NULL,
  `date` varchar(255) NOT NULL,
  `user_session` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `on_hold`
--

INSERT INTO `on_hold` (`id`, `invoice_number`, `medicine_name`, `category`, `expire_date`, `qty`, `type`, `cost`, `amount`, `profit_amount`, `date`, `user_session`) VALUES
(1, 'CA-9390009', 'Biogesic', 'Painkiller', '2020-03-31', 1, 'Stp', 9, 9, 4, '02/22/2022', NULL),
(2, 'CA-2200239', 'Biogesic', 'Painkiller', '2020-03-31', 298, 'Stp', 9, 2682, 1192, '02/22/2022', NULL),
(4, 'CA-2099902', 'Paracetemol', 'Painkiller', '2019-08-15', 1, 'Bot', 2, 2, 1, '02/27/2022', NULL),
(7, 'CA-2922209', 'Paracetemol', 'Painkiller', '2019-08-15', 3, 'Bot', 2, 6, 3, '02/27/2022', NULL),
(17, 'CA-3920020', 'Paracetemol', 'Painkiller', '2019-02-28', 10, 'Bot', 2, 20, 10, '02/28/2022', NULL),
(18, 'CA-9009003', 'Paracetemol', 'Painkiller', '2019-02-28', 3, 'Bot', 2, 6, 3, '02/28/2022', NULL),
(19, 'CA-9092090', 'Paracetemol', 'Painkiller', '2019-02-28', 2, 'Bot', 2, 4, 2, '02/28/2022', NULL),
(20, 'CA-9220309', 'Paracetemol', 'Painkiller', '2019-02-28', 2, 'Bot', 2, 4, 2, '03/01/2022', NULL),
(21, 'CA-0322209', 'Paracetemol', 'Painkiller', '2019-02-28', 93, 'Bot', 2, 186, 93, '03/01/2022', NULL),
(22, 'CA-2990220', 'Paracetemol', 'Painkiller', '2019-02-28', 8, 'Bot', 2, 16, 8, '03/01/2022', NULL),
(23, 'CA-0939993', 'Paracetemol', 'Painkiller', '2019-02-28', 1, 'Bot', 2, 2, 1, '03/02/2022', NULL),
(24, 'CA-9900203', 'Biogesic', 'Painkiller', '2019-11-14', 1, 'Sachet', 9, 9, 4, '03/02/2022', NULL),
(25, 'CA-9900203', 'Paracetemol', 'Painkiller', '2019-09-19', 2, 'Stp', 2, 4, 2, '03/02/2022', NULL),
(26, 'CA-9090000', 'Biogesic', 'Painkiller', '2019-11-14', 2, 'Sachet', 2, 4, 2, '03/02/2022', NULL),
(27, 'CA-2233020', 'Biogesic', 'Painkiller', '2020-03-13', 5, 'Unit', 9, 45, 20, '03/02/2022', NULL),
(29, 'CA-9292200', 'Biogesic', 'Painkiller', '2019-04-25', 1, 'Bot', 9, 9, 4, '03/02/2022', NULL),
(30, 'CA-3009023', 'Paracetemol', 'Painkiller', '2019-08-14', 3, 'Unit', 2, 6, 3, '03/02/2022', NULL),
(35, 'CA-0900090', 'Paracetemol', 'Painkiller', '2019-08-14', 2, 'Bot', 2, 4, 2, '03/02/2019', NULL),
(37, 'CA-2099202', 'Paracetemol', 'painkiller', '2011-12-19', 1, 'Bot', 2, 2, 1, '03/04/2022', NULL),
(51, 'CA-9292203', 'Paracetemol', 'Painkiller', '2019-08-03', 3, 'Stp', 2, 6, 3, '03/05/2022', NULL),
(61, 'CA-0000032', 'Paracetemol', 'Painkiller', '2019-10-01', 5, 'Bot', 2, 10, 5, '03/05/2022', NULL),
(62, 'CA-0000032', 'Biogesic', 'Painkiller', '2020-03-06', 4, 'Bot', 9, 36, 20, '03/05/2022', NULL),
(63, 'CA-2909290', 'Paracetemol', 'Painkiller', '2019-10-01', 10, 'Bot', 2, 20, 10, '03/05/2022', NULL),
(64, 'CA-2929293', 'Demo Med', 'Demo Category', '2023-07-06', 12, 'Tab', 18, 216, 96, '08/06/2022', NULL),
(66, 'CA-0020090', 'Doxycycline', 'Antibiotics', '2025-08-09', 5, 'Tab', 4, 20, 10, '08/13/2022', NULL),
(67, 'CA-0290929', 'Vitamin B12', 'Vitamins', '2026-11-10', 3, 'Tab', 19, 57, 27, '08/13/2022', NULL),
(68, 'CA-9303020', 'Deplin', 'Vitamins', '2026-09-14', 6, 'Sachet', 141, 846, 168, '08/13/2022', NULL),
(73, 'CA-2920002', 'Fluconazole', 'Antifungals', '2026-08-13', 3, 'Tab', 29, 87, 21, '08/13/2022', NULL),
(74, 'CA-3020292', 'Estazolam', 'Sedatives', '2026-08-26', 12, 'Bot', 54, 648, 156, '08/13/2022', NULL),
(76, 'CA-0092000', 'Econazole', 'Antifungals', '2027-11-17', 8, 'Sachet', 24, 192, 56, '08/13/2022', NULL),
(78, 'CA-9092029', 'Vitamin B12', 'Vitamins', '2026-11-10', 7, 'Tab', 19, 133, 63, '08/13/2022', NULL),
(79, 'CA-9092029', 'Econazole', 'Antifungals', '2027-11-17', 2, 'Sachet', 24, 48, 14, '08/13/2022', NULL),
(80, 'CA-0009392', 'Fluconazole', 'Antifungals', '2026-08-13', 3, 'Tab', 29, 87, 21, '08/13/2022', NULL),
(81, 'CA-2020390', 'Altretamine', 'Antineoplastics', '2026-08-12', 9, 'Sachet', 87, 783, 126, '08/13/2022', NULL),
(82, 'CA-2030293', 'Mucinex', 'Expectorant', '2026-08-25', 14, 'Bot', 37, 518, 112, '08/13/2022', NULL),
(83, 'CA-9090029', 'Methisazone', 'Antiviral', '2026-08-03', 4, 'Tab', 12, 48, 16, '08/13/2022', NULL),
(84, 'CA-9090029', 'Alprazolam', 'Tranquilizer', '2026-10-06', 5, 'Tab', 19, 95, 45, '08/13/2022', NULL),
(85, 'CA-3909093', 'Fluconazole', 'Antifungals', '2026-08-13', 5, 'Tab', 29, 145, 35, '08/13/2022', NULL),
(96, 'CA-2999922', 'Astra', 'Antifungals', '2023-12-23', 1, 'Bot', 15, 15, 3, '07/23/2023', NULL),
(97, 'CA-2999922', 'Alprazolam', 'Tranquilizer', '2023-03-06', 282, 'Bot', 19, 5358, 2538, '07/23/2023', NULL),
(98, 'CA-9229290', 'Astra', 'Antifungals', '2023-12-23', 2, 'Bot', 15, 30, 6, '07/23/2023', NULL),
(99, 'CA-0039900', 'Astra', 'Antifungals', '2023-12-23', 117, 'Bot', 15, 1755, 351, '07/23/2023', NULL),
(100, 'CA-0300299', 'Estazolam', 'Sedatives', '2026-08-26', 50, 'Bot', 54, 2700, 650, '07/24/2023', NULL),
(101, 'CA-0900003', 'Demo Med', 'Demo Category', '2024-04-17', 70, 'Bot', 18, 1260, 560, '07/24/2023', NULL),
(102, 'CA-9290290', 'Demo Med', 'Demo Category', '2024-04-17', 10, 'Bot', 18, 180, 80, '07/24/2023', NULL),
(103, 'CA-0923290', 'Estazolam', 'Sedatives', '2026-08-26', 100, 'Bot', 54, 5400, 1300, '07/24/2023', NULL),
(105, 'CA-9920909', 'Doxycycline', 'Antibiotics', '2025-08-09', 10, 'Tab', 4, 40, 20, '07/24/2023', NULL),
(106, 'CA-9000000', 'Doxycycline', 'Antibiotics', '2025-08-09', 90, 'Tab', 4, 360, 180, '07/25/2023', NULL),
(107, 'CA-2329290', 'Estazolam', 'Sedatives', '2023-08-26', 200, 'Bot', 54, 10800, 2600, '07/25/2023', NULL),
(108, 'CA-9099302', 'Fansidar', 'Antimalarial', '2023-12-18', 100, 'Bot', 1500, 150000, 30000, '07/25/2023', NULL),
(109, 'CA-9900223', 'Flagyl', 'Amebicides', '2024-09-25', 198, 'Unit', 2000, 396000, 99000, '07/25/2023', NULL),
(110, 'CA-2222209', 'Alinia', 'Amebicides', '2024-09-09', 100, 'Bot', 7300, 730000, 74000, '07/25/2023', NULL),
(111, 'CA-0390000', 'Cetizine', 'Antibiotics', '2024-02-25', 120, 'Tab', 1000, 120000, 60000, '07/25/2023', NULL),
(112, 'CA-9990920', 'Acetaminophen', 'Pain reliever', '2026-07-25', 200, 'Bot', 5500, 1100000, 300000, '08/07/2023', NULL),
(113, 'CA-2000099', 'Flagyl', 'Amebicides', '2024-09-25', 2, 'Bot', 2000, 4000, 1000, '08/07/2023', NULL),
(114, 'CA-2000099', 'Pracetamol', 'Pain killer', '2023-09-09', 10, 'Bot', 2300, 23000, 3000, '08/07/2023', NULL),
(115, 'CA-2000099', 'Acetaminophen', 'Pain reliever', '2026-07-25', 10, 'Bot', 5500, 55000, 15000, '08/07/2023', NULL),
(116, 'CA-9020030', 'Acetaminophen', 'Pain reliever', '2026-07-25', 8, 'Bot', 5500, 44000, 12000, '08/08/2023', NULL),
(117, 'CA-9020030', 'Fansidar', 'Antimalarial', '2023-12-18', 8, 'Bot', 1500, 12000, 2400, '08/08/2023', NULL),
(118, 'CA-9020030', 'Coartem', 'Antimalarial', '2024-07-09', 10, 'Bot', 1500, 15000, 2700, '08/08/2023', NULL),
(119, 'CA-0203930', 'Cloxacillin', 'Antibiotics', '2025-02-11', 9, 'Bot', 1300, 11700, 1800, '08/09/2023', NULL),
(120, 'CA-9090202', 'Acetaminophen', 'Pain reliever', '2026-07-25', 2, 'Bot', 5500, 11000, 3000, '08/09/2023', NULL),
(121, 'CA-9090202', 'Cloxacillin', 'Antibiotics', '2025-02-11', 1, 'Bot', 1300, 1300, 200, '08/09/2023', NULL),
(122, 'CA-9090202', 'Alinia', 'Amebicides', '2024-09-09', 2, 'Bot', 7300, 14600, 1480, '08/09/2023', NULL),
(123, 'CA-0000002', 'Cloxacillin', 'Antibiotics', '2025-02-11', 1, 'Bot', 1300, 1300, 200, '08/09/2023', NULL),
(124, 'CA-0009030', 'Cloxacillin', 'Antibiotics', '2025-02-11', 9, 'Bot', 1300, 11700, 1800, '08/09/2023', NULL),
(125, 'CA-0009030', 'Acetaminophen', 'Pain reliever', '2026-07-25', 11, 'Bot', 5500, 60500, 16500, '08/09/2023', NULL),
(126, 'CA-2929202', 'Cloxacillin', 'Antibiotics', '2025-02-11', 5, 'Bot', 1300, 6500, 1000, '08/09/2023', NULL),
(127, 'CA-0929320', 'Acetaminophen', 'Pain reliever', '2026-07-25', 1, 'Bot', 5500, 5500, 1500, '08/09/2023', NULL),
(128, 'CA-0929320', 'Alinia', 'Amebicides', '2024-09-09', 2, 'Bot', 7300, 14600, 1480, '08/09/2023', NULL),
(129, 'CA-0929320', 'Coartem', 'Antimalarial', '2024-07-09', 3, 'Bot', 1500, 4500, 810, '08/09/2023', NULL),
(130, 'CA-9090002', 'Coartem', 'Antimalarial', '2024-07-09', 3, 'Bot', 1500, 4500, 810, '08/09/2023', NULL),
(131, 'CA-0230930', 'Cloxacillin', 'Antibiotics', '2025-02-11', 1, 'Bot', 1300, 1300, 200, '08/09/2023', NULL),
(132, 'CA-2090203', 'Flagyl', 'Amebicides', '2024-09-25', 1, 'Bot', 2000, 2000, 500, '08/09/2023', NULL),
(133, 'CA-9092002', 'Cloxacillin', 'Antibiotics', '2025-02-11', 1, 'Bot', 1300, 1300, 200, '08/09/2023', NULL),
(134, 'CA-0909003', 'Fansidar', 'Antimalarial', '2023-12-18', 68, 'Bot', 1500, 102000, 20400, '08/10/2023', NULL),
(135, 'pharmacist', 'CA-0992290', 'Acetaminophen', '0000-00-00', 2026, '1', 0, 5500, 5500, '1500', '08/11/2023'),
(136, 'pharmacist', 'CA-0992290', 'Acetaminophen', '0000-00-00', 2026, '1', 0, 5500, 5500, '1500', '08/11/2023'),
(137, 'CA-0992290', 'Acetaminophen', 'Pain reliever', '2026-07-25', 1, 'Bot', 5500, 5500, 1500, '08/11/2023', 'pharmacist'),
(138, 'CA-9920000', 'Acetaminophen', 'Pain reliever', '2026-07-25', 1, 'Bot', 5500, 5500, 1500, '08/11/2023', 'mumbere'),
(139, 'CA-9920000', 'Coartem', 'Antimalarial', '2024-07-09', 1, 'Bot', 1500, 1500, 270, '08/11/2023', 'mumbere'),
(140, 'CA-9220029', 'Acetaminophen', 'Pain reliever', '2026-07-25', 1, 'Bot', 5500, 5500, 1500, '08/11/2023', 'mumbere'),
(141, 'CA-0000902', 'Fansidar', 'Antimalarial', '2023-12-18', 2, 'Bot', 1500, 3000, 600, '08/11/2023', 'PK'),
(148, 'CA-0903332', 'Acetaminophen', 'Pain reliever', '2026-07-25', 1, 'Bot', 0, 0, 0, '08/11/2023', 'mumbere'),
(149, 'CA-9900929', 'Acetaminophen', 'Pain reliever', '2026-07-25', 1, 'Bot', 0, 0, 0, '08/13/2023', 'mumbere'),
(151, 'CA-0202992', 'Pp', 'D', '2024-03-11', 1, 'Bot', 0, 0, 0, '10/04/2023', 'PK'),
(152, 'CA-9009020', 'Cetrizine', 'Antibiotics', '2024-02-25', 1, 'Bot', 0, 0, 0, '10/04/2023', 'PK'),
(153, 'CA-2029209', 'Panadol', 'Pain killer', '2025-12-12', 1, 'Bot', 0, 0, 0, '10/04/2023', 'PK'),
(155, 'CA-2000220', 'Alprazolam', 'Tranquilizer', '2026-10-06', 1, 'Tab', 19, 19, 9, '10/30/2023', 'PK'),
(156, 'CA-2390030', 'Lydia post pill', '1.5mg', '2025-02-28', 1, 'Bot', 5000, 5000, 3400, '10/30/2023', 'PK'),
(157, 'CA-0220990', 'Rivotril', 'Tabs', '2026-01-30', 5, 'Tab', 1000, 5000, 2500, '10/30/2023', 'PK'),
(158, 'CA-2020990', 'Panadol extra', 'Tbs', '2025-03-31', 10, 'Bot', 250, 2500, 1000, '10/30/2023', 'PK'),
(159, 'CA-0303990', 'Lydia post pill', '1.5mg', '2025-02-28', 1, 'Bot', 5000, 5000, 3400, '10/30/2023', 'PK'),
(160, 'CA-0003930', 'Recodin syrup', '100ml', '2025-06-30', 1, 'Bot', 6000, 6000, 2400, '10/30/2023', 'Audrey'),
(161, 'CA-0990009', 'Panadol extra', 'Tbs', '2025-03-31', 10, 'Bot', 250, 2500, 1000, '10/30/2023', 'Audrey'),
(162, 'CA-0099039', 'Panadol extra', 'Tbs', '2025-03-31', 4, 'Bot', 250, 1000, 400, '10/30/2023', 'Audrey'),
(163, 'CA-3299029', 'Dexona Ear-eye drop', 'Cadilla', '2025-04-30', 1, 'Bot', 4000, 4000, 2350, '10/30/2023', 'Audrey'),
(164, 'CA-0309032', 'Flufed tbs', 'Tbs', '2024-04-30', 10, 'Tab', 200, 2000, 1000, '10/30/2023', 'Audrey'),
(166, 'CA-0000000', 'Artesunate 120mg inj', 'Royal', '2025-01-31', 1, 'Bot', 7000, 7000, 1900, '10/30/2023', 'Audrey'),
(167, 'CA-2230909', 'Rivotril', 'Tabs', '2026-01-30', 10, 'Tab', 1000, 10000, 5000, '10/30/2023', 'Audrey'),
(168, 'CA-9909902', 'Predsolone ', 'Tabs', '2025-12-31', 10, 'Tab', 100, 1000, 500, '10/30/2023', 'Audrey'),
(169, 'CA-0999209', 'Tramadol capsule', 'Tabs', '2028-10-31', 5, 'Bot', 200, 1000, 500, '10/30/2023', 'Audrey'),
(170, 'CA-0029303', 'Roxene 1gm ', 'Cef', '2026-02-28', 10, 'Bot', 1500, 15000, 6500, '10/30/2023', 'Audrey'),
(171, 'CA-0090009', 'Artesunate 120mg inj', 'Royal', '2025-01-31', 1, 'Bot', 7000, 7000, 1900, '10/30/2023', 'Audrey'),
(172, 'CA-0029090', 'Artesunate 60mg', 'Injection', '2026-02-28', 2, 'Bot', 3500, 7000, 2000, '10/30/2023', 'Audrey'),
(174, 'CA-0930209', 'Coldcap', 'Tabs', '2025-10-30', 10, 'Bot', 300, 3000, 1500, '10/30/2023', 'Audrey'),
(175, 'CA-3003902', 'Benzhexol', 'Tabs', '2026-10-30', 10, 'Bot', 200, 2000, 1000, '10/30/2023', 'Audrey'),
(176, 'CA-9009099', 'Benzhexol', 'Tabs', '2026-10-30', 10, 'Bot', 200, 2000, 1000, '10/30/2023', 'Audrey'),
(177, 'CA-0290090', 'Coldcap', 'Tabs', '2025-10-30', 6, 'Bot', 300, 1800, 900, '10/30/2023', 'Audrey'),
(178, 'CA-2222009', 'Benzhexol', 'Tabs', '2026-10-30', 10, 'Bot', 200, 2000, 1000, '10/30/2023', 'Audrey'),
(179, 'CA-0209099', 'Albendazole', 'Tabs', '2025-10-30', 1, 'Bot', 2000, 2000, 1000, '10/30/2023', 'Audrey'),
(180, 'CA-9090332', 'Paracetamol', 'Tabs', '2026-03-13', 10, 'Bot', 100, 1000, 500, '10/30/2023', 'Audrey'),
(181, 'CA-0909900', 'Examination Gloves', 'Medical', '2025-01-31', 1, 'Bot', 1000, 1000, 200, '10/30/2023', 'Audrey'),
(182, 'CA-0092902', 'Cough linctus', 'Sys', '2025-10-31', 1, 'Bot', 2500, 2500, 1000, '10/30/2023', 'Audrey'),
(183, 'CA-0092902', 'Amoxyl', 'Tabs', '2025-10-30', 20, 'Bot', 100, 2000, 1000, '10/30/2023', 'Audrey'),
(184, 'CA-0902090', 'Piroxicam', 'Tabs', '2025-10-30', 10, 'Bot', 100, 1000, 500, '10/30/2023', 'Audrey'),
(185, 'CA-0022329', 'Piroxicam', 'Tabs', '2025-10-30', 10, 'Bot', 100, 1000, 500, '10/30/2023', 'Audrey'),
(186, 'CA-9029299', 'Piroxicam', 'Tabs', '2025-10-30', 10, 'Bot', 100, 1000, 500, '10/30/2023', 'Audrey'),
(187, 'CA-0029200', 'Artesunate 120mg inj', 'Royal', '2025-01-31', 1, 'Bot', 7000, 7000, 1900, '10/30/2023', 'Audrey'),
(188, 'CA-2002002', 'Toff plus', 'Tabs', '2025-06-30', 5, 'Bot', 500, 2500, 1250, '10/30/2023', 'Audrey'),
(189, 'CA-2002002', 'Ampiclox', 'Tabs', '2026-01-31', 10, 'Bot', 200, 2000, 1000, '10/30/2023', 'Audrey'),
(190, 'CA-9203309', 'Metro tabs', 'Cps', '2026-04-30', 10, 'Bot', 100, 1000, 500, '10/30/2023', 'Audrey'),
(192, 'CA-9203309', 'Panadol extra', 'Tbs', '2025-03-31', 4, 'Bot', 250, 1000, 400, '10/30/2023', 'Audrey'),
(193, 'CA-9203309', 'Piroxicam', 'Tabs', '2025-10-30', 10, 'Bot', 100, 1000, 500, '10/30/2023', 'Audrey'),
(194, 'CA-0200020', 'Ampiclox', 'Tabs', '2026-01-31', 5, 'Bot', 200, 1000, 500, '10/30/2023', 'Audrey'),
(195, 'CA-9902229', 'Strepsils', 'Tabs', '2025-02-28', 4, 'Bot', 500, 2000, 1200, '10/30/2023', 'Audrey'),
(196, 'CA-0320929', 'Zepar tablets', 'Tabs', '2026-12-31', 1, 'Bot', 3500, 3500, 1500, '10/30/2023', 'Audrey'),
(197, 'CA-0329200', 'Extradol', 'Tabs', '2025-12-31', 2, 'Bot', 500, 1000, 500, '10/30/2023', 'Audrey'),
(198, 'CA-0329200', 'Sinarest', 'Tabs', '2026-12-31', 1, 'Bot', 1000, 1000, 500, '10/30/2023', 'Audrey'),
(199, 'CA-3090002', 'Backup pill', 'Pill', '2027-03-12', 1, 'Bot', 8000, 8000, 5400, '10/30/2023', 'Audrey'),
(200, 'CA-9009900', 'Backup pill', 'Pill', '2027-03-12', 1, 'Bot', 8000, 8000, 5400, '10/30/2023', 'Audrey'),
(201, 'CA-0992000', 'Ampiclox', 'Tabs', '2026-01-31', 10, 'Bot', 200, 2000, 1000, '10/30/2023', 'Audrey'),
(202, 'CA-0003030', 'Legnment ', 'Spray', '2025-01-31', 1, 'Bot', 4000, 4000, 2000, '10/30/2023', 'Audrey'),
(203, 'CA-2290099', 'Surgical blade', 'Lade', '2025-10-30', 1, 'Bot', 1000, 1000, 500, '10/30/2023', 'Audrey'),
(205, 'CA-2200039', 'Diazepam', 'Tabs', '2025-10-30', 10, 'Bot', 300, 3000, 1500, '10/30/2023', 'Audrey'),
(206, 'CA-9090309', 'Cotton wool 100mg', '100mg', '2026-11-30', 1, 'Bot', 2000, 2000, 1000, '10/30/2023', 'Audrey'),
(207, 'CA-0900232', 'Phendabitol', 'Tabs', '2026-10-30', 10, 'Bot', 200, 2000, 1000, '10/30/2023', 'Audrey'),
(208, 'CA-0900390', 'Surgical spirit', 'Spirit', '2024-09-30', 1, 'Bot', 4000, 4000, 2000, '10/30/2023', 'Audrey'),
(209, 'CA-9009209', 'Ma-kare', 'Tabs', '2025-10-30', 1, 'Bot', 50000, 50000, 32000, '10/30/2023', 'Audrey'),
(211, 'CA-9009209', 'Metro tabs', 'Cps', '2026-04-30', 30, 'Bot', 100, 3000, 1500, '10/30/2023', 'Audrey'),
(212, 'CA-9009209', 'Ibuprofen', 'Tbs', '2025-12-31', 20, 'Bot', 100, 2000, 1000, '10/30/2023', 'Audrey'),
(213, 'CA-9009209', 'Ampiclox', 'Tabs', '2026-01-31', 20, 'Bot', 200, 4000, 2000, '10/30/2023', 'Audrey'),
(214, 'CA-0939002', 'HCG strip', 'Strip', '2027-02-28', 1, 'Bot', 2000, 2000, 1200, '10/30/2023', 'Audrey'),
(216, 'CA-9999920', 'Ampicillin', 'Tabs', '2025-10-30', 10, 'Bot', 200, 2000, 1200, '10/30/2023', 'Audrey'),
(217, 'CA-0000099', 'Loperamide', 'Tbs', '2026-10-30', 10, 'Bot', 100, 1000, 200, '10/30/2023', 'Audrey'),
(218, 'CA-3099022', 'Recodin syrup', '100ml', '2025-06-30', 1, 'Bot', 6000, 6000, 2400, '10/30/2023', 'Audrey'),
(219, 'CA-0003900', 'Action tbs', 'Tbs', '2027-10-31', 4, 'Bot', 250, 1000, 200, '10/30/2023', 'Audrey'),
(220, 'CA-9909990', 'Pen V (Unipen)', 'Tabs', '2025-08-31', 5, 'Bot', 200, 1000, 750, '10/30/2023', 'Audrey'),
(221, 'CA-0990909', 'Sinarest', 'Tabs', '2026-12-31', 1, 'Bot', 1000, 1000, 500, '10/30/2023', 'Audrey'),
(222, 'CA-9230920', 'Unisten cream', 'Cream', '2026-04-30', 1, 'Bot', 4000, 4000, 1500, '10/30/2023', 'Audrey'),
(223, 'CA-3092229', 'HCG strip', 'Strip', '2027-02-28', 1, 'Bot', 2000, 2000, 1200, '10/30/2023', 'Audrey'),
(224, 'CA-0339920', 'Lydia post pill', '1.5mg', '2025-02-28', 1, 'Bot', 5000, 5000, 3400, '10/30/2023', 'Audrey'),
(225, 'CA-9390229', 'Lydia post pill', '1.5mg', '2025-02-28', 1, 'Bot', 5000, 5000, 3400, '10/30/2023', 'Audrey'),
(226, 'CA-2029922', 'Septrine 960mg', 'Tabs', '2026-02-08', 5, 'Bot', 200, 1000, 500, '10/30/2023', 'Audrey'),
(227, 'CA-9930900', 'Tramadol capsule', 'Tabs', '2028-10-31', 10, 'Bot', 200, 2000, 1000, '10/30/2023', 'Audrey'),
(228, 'CA-0029390', 'Misoclear', 'Tabs', '2025-02-28', 5, 'Bot', 10000, 50000, 27500, '10/30/2023', 'Audrey'),
(229, 'CA-0029390', 'Metro tabs', 'Cps', '2026-04-30', 30, 'Bot', 100, 3000, 1500, '10/30/2023', 'Audrey'),
(230, 'CA-0029390', 'Ibupar', 'Tabs', '2025-12-31', 10, 'Bot', 100, 1000, 500, '10/30/2023', 'Audrey'),
(231, 'CA-0029390', 'Ampiclox', 'Tabs', '2026-01-31', 20, 'Bot', 200, 4000, 2000, '10/30/2023', 'Audrey'),
(232, 'CA-0929330', 'Toractine syrup', 'Syp', '2025-02-28', 1, 'Bot', 6000, 6000, 1800, '10/30/2023', 'Audrey'),
(233, 'CA-0200000', 'Action tbs', 'Tbs', '2027-10-31', 4, 'Bot', 250, 1000, 200, '10/30/2023', 'Audrey'),
(234, 'CA-0922900', 'Mediven cream', 'Cream', '2005-03-13', 2, 'Bot', 4000, 8000, 4000, '10/30/2023', 'Audrey'),
(235, 'CA-2900290', 'Toff plus', 'Tabs', '2025-06-30', 4, 'Bot', 500, 2000, 1000, '10/30/2023', 'Audrey'),
(236, 'CA-2299002', 'Carbamezapine', 'Tbs', '2027-12-31', 10, 'Bot', 200, 2000, 1000, '10/30/2023', 'Audrey'),
(237, 'CA-2999900', 'Painex', 'Tbs', '2025-12-31', 2, 'Bot', 500, 1000, 500, '10/30/2023', 'Audrey'),
(238, 'CA-2320032', 'Lydia post pill', '1.5mg', '2025-02-28', 1, 'Bot', 5000, 5000, 3400, '10/30/2023', 'Audrey'),
(239, 'CA-9200992', 'Panadol advance', 'Tabs', '2025-12-31', 10, 'Bot', 200, 2000, 1000, '10/30/2023', 'Audrey'),
(240, 'CA-0090929', 'Omperazole', 'Tabs', '2025-12-31', 5, 'Bot', 200, 1000, 500, '10/30/2023', 'Audrey'),
(241, 'CA-0299090', 'Panadol extra', 'Tbs', '2025-03-31', 4, 'Bot', 250, 1000, 400, '10/30/2023', 'Audrey'),
(242, 'CA-0300393', 'Sinarest', 'Tabs', '2026-12-31', 1, 'Bot', 1000, 1000, 500, '10/30/2023', 'Audrey'),
(243, 'CA-9393999', 'Tramadol capsule', 'Tabs', '2028-10-31', 10, 'Bot', 200, 2000, 1000, '10/30/2023', 'Audrey'),
(244, 'CA-0932902', 'HCG strip', 'Strip', '2027-02-28', 1, 'Bot', 2000, 2000, 1200, '10/30/2023', 'Audrey'),
(245, 'CA-2020209', 'Panadol extra', 'Tbs', '2025-03-31', 6, 'Bot', 250, 1500, 600, '10/30/2023', 'Audrey'),
(246, 'CA-0222933', 'Kiss stawberry condom', 'Pac', '2026-11-30', 1, 'Bot', 2000, 2000, 1200, '10/30/2023', 'Audrey'),
(247, 'CA-0900032', 'Kiss stawberry condom', 'Pac', '2026-11-30', 1, 'Bot', 2000, 2000, 1200, '10/30/2023', 'Audrey'),
(248, 'CA-0003029', 'Menthxy longezes', 'Pck', '2026-11-30', 2, 'Bot', 500, 1000, 800, '10/30/2023', 'Audrey'),
(249, 'CA-0003029', 'Omeprazole', 'Tabs', '2025-12-31', 10, 'Bot', 200, 2000, 1000, '10/30/2023', 'Audrey'),
(250, 'CA-0092900', 'MCG cream', 'Cream', '2025-12-31', 1, 'Bot', 6000, 6000, 1500, '10/30/2023', 'Audrey'),
(251, 'CA-0092900', 'Pirican', 'Tabs', '2024-02-28', 10, 'Bot', 100, 1000, 500, '10/30/2023', 'Audrey'),
(252, 'CA-9900999', 'Toff plus', 'Tabs', '2025-06-30', 2, 'Bot', 500, 1000, 500, '10/30/2023', 'Audrey'),
(253, 'CA-0939009', 'P-Alaxin', ' 40mg/320mg', '2028-12-31', 1, 'Bot', 12000, 12000, 4800, '10/30/2023', 'Audrey'),
(254, 'CA-3339923', 'Lydia post pill', '1.5mg', '2025-02-28', 2, 'Bot', 5000, 10000, 6800, '10/30/2023', 'Audrey'),
(255, 'CA-2200923', 'Panadol extra', 'Tbs', '2025-03-31', 4, 'Bot', 250, 1000, 400, '10/30/2023', 'Audrey'),
(256, 'CA-0922220', 'Lydia post pill', '1.5mg', '2025-02-28', 1, 'Bot', 5000, 5000, 3400, '10/30/2023', 'Audrey'),
(257, 'CA-0929229', 'Nasatab tbs', 'Tbs', '2026-02-28', 10, 'Bot', 500, 5000, 3000, '10/30/2023', 'Audrey'),
(258, 'CA-9003039', 'Biscodyl', 'Tbs', '2027-06-30', 10, 'Bot', 100, 1000, 500, '10/30/2023', 'Audrey'),
(259, 'CA-9003039', 'Panadol extra', 'Tbs', '2025-03-31', 10, 'Bot', 250, 2500, 1000, '10/30/2023', 'Audrey'),
(260, 'CA-0000009', 'Chlerphemin', 'Tbs', '2026-05-30', 1, 'Bot', 500, 500, 300, '10/30/2023', 'Audrey');

-- --------------------------------------------------------

--
-- Table structure for table `pharmacist`
--

CREATE TABLE `pharmacist` (
  `pharmacist_id` tinyint(5) NOT NULL,
  `first_name` varchar(15) NOT NULL,
  `last_name` varchar(15) NOT NULL,
  `staff_id` varchar(10) NOT NULL,
  `postal_address` varchar(20) NOT NULL,
  `phone` varchar(12) NOT NULL,
  `email` varchar(20) NOT NULL,
  `username` varchar(10) NOT NULL,
  `password` varchar(255) NOT NULL,
  `date` datetime NOT NULL,
  `gender` enum('Male','Female') NOT NULL,
  `role` enum('Nurse','Marketer','Pharmacist') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `pharmacist`
--

INSERT INTO `pharmacist` (`pharmacist_id`, `first_name`, `last_name`, `staff_id`, `postal_address`, `phone`, `email`, `username`, `password`, `date`, `gender`, `role`) VALUES
(8, 'peace', 'kevin', '1', 'Kibloka', '0707064552', 'willian@ask.pham', 'PK', '$2y$10$FkatPB05mFa77uXb0c0ITO14bPYodrH7q46QX/a.4rfzF7Fz/nDE2', '2023-08-11 19:54:14', 'Male', 'Nurse'),
(9, 'Tumubwiine', 'Audrey', '1', 'Rushenyi-Ntungamo', '0775071745', 'audreyasset1999@gmai', 'Audrey', '$2y$10$rOt12tAW4iKNp5/nPhrtaO.D.rxix.67KcLhTHmd3FqFEU6W.Kc9u', '2023-08-11 21:03:44', 'Female', 'Nurse');

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `id` int(11) NOT NULL,
  `invoice_number` varchar(13) NOT NULL,
  `medicines` varchar(255) NOT NULL,
  `quantity` varchar(255) NOT NULL,
  `total_amount` bigint(11) NOT NULL,
  `total_profit` bigint(11) NOT NULL,
  `Date` date NOT NULL,
  `user_session` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`id`, `invoice_number`, `medicines`, `quantity`, `total_amount`, `total_profit`, `Date`, `user_session`) VALUES
(2, 'CA-0900090', 'Biogesic', '2(Stp)', 18, 8, '2022-07-06', NULL),
(3, 'CA-2099902', 'Paracetemol', '1(Bot)', 2, 1, '2022-07-06', NULL),
(4, 'CA-2922209', 'Paracetemol', '3(Bot)', 6, 3, '2022-07-07', NULL),
(5, 'CA-3920020', 'Paracetemol', '10(Bot)', 20, 10, '2022-07-09', NULL),
(6, 'CA-9009003', 'Paracetemol', '3(Bot)', 6, 3, '2022-07-09', NULL),
(7, 'CA-9220309', 'Paracetemol', '2(Bot)', 4, 2, '2022-07-18', NULL),
(8, 'CA-0322209', 'Paracetemol', '93(Bot)', 186, 93, '2022-07-19', NULL),
(9, 'CA-0939993', 'Paracetemol', '1(Bot)', 2, 1, '2022-07-20', NULL),
(10, 'CA-9900203', 'Biogesic,Paracetemol', '1(Sachet),2(Stp)', 13, 6, '2022-07-20', NULL),
(11, 'CA-2233020', 'Biogesic', '5(Unit)', 45, 20, '2022-07-20', NULL),
(12, 'CA-9292200', 'Biogesic', '1(Bot)', 9, 4, '2022-07-27', NULL),
(13, 'CA-2099202', 'Paracetemol', '1(Bot)', 2, 1, '2022-07-27', NULL),
(14, 'CA-9292203', 'Paracetemol', '3(Stp)', 6, 3, '2022-07-27', NULL),
(15, 'CA-0000032', 'Paracetemol,Biogesic', '5(Bot),4(Bot)', 46, 21, '2022-07-27', NULL),
(16, 'CA-2929293', 'Demo Med', '12(Tab)', 216, 96, '2022-08-06', NULL),
(17, 'CA-0020090', 'Doxycycline', '5(Tab)', 20, 10, '2022-08-13', NULL),
(18, 'CA-0290929', 'Vitamin B12', '3(Tab)', 57, 27, '2022-08-13', NULL),
(19, 'CA-9303020', 'Deplin', '6(Sachet)', 846, 168, '2022-08-13', NULL),
(20, 'CA-2920002', 'Fluconazole', '3(Tab)', 87, 21, '2022-08-13', NULL),
(21, 'CA-3020292', 'Estazolam', '12(Bot)', 648, 156, '2022-08-13', NULL),
(22, 'CA-0092000', 'Econazole', '8(Sachet)', 192, 56, '2022-08-13', NULL),
(23, 'CA-9092029', 'Vitamin B12,Econazole', '7(Tab),2(Sachet)', 181, 77, '2022-08-13', NULL),
(24, 'CA-0009392', 'Fluconazole', '3(Tab)', 87, 21, '2022-08-13', NULL),
(25, 'CA-2020390', 'Altretamine', '9(Sachet)', 783, 126, '2022-08-13', NULL),
(26, 'CA-2030293', 'Mucinex', '14(Bot)', 518, 112, '2022-08-13', NULL),
(27, 'CA-9090029', 'Methisazone,Alprazolam', '4(Tab),5(Tab)', 143, 61, '2022-08-13', NULL),
(28, 'CA-3909093', 'Fluconazole', '5(Tab)', 145, 35, '2022-08-13', NULL),
(29, 'CA-9229290', 'Astra', '2(Bot)', 30, 6, '2023-07-23', NULL),
(30, 'CA-0039900', 'Astra', '117(Bot)', 1755, 351, '2023-07-23', NULL),
(31, 'CA-0300299', 'Estazolam', '50(Bot)', 2700, 650, '2023-07-24', NULL),
(32, 'CA-0900003', 'Demo Med', '70(Bot)', 1260, 560, '2023-07-24', NULL),
(33, 'CA-9290290', 'Demo Med', '10(Bot)', 180, 80, '2023-07-24', NULL),
(34, 'CA-0923290', 'Estazolam', '100(Bot)', 5400, 1300, '2023-07-24', NULL),
(35, 'CA-0923290', 'Estazolam', '100(Bot)', 5400, 1300, '2023-07-24', NULL),
(36, 'CA-0930209', 'Doxycycline', '90(Tab)', 360, 180, '2023-07-24', NULL),
(37, 'CA-9920909', 'Doxycycline', '10(Tab)', 40, 20, '2023-07-24', NULL),
(38, 'CA-9000000', 'Doxycycline', '90(Tab)', 360, 180, '2023-07-25', NULL),
(39, 'CA-2329290', 'Estazolam', '200(Bot)', 10800, 2600, '2023-07-25', NULL),
(40, 'CA-9900223', 'Flagyl', '198(Unit)', 396000, 99000, '2023-07-25', NULL),
(41, 'CA-2222209', 'Alinia', '100(Bot)', 730000, 74000, '2023-07-25', NULL),
(42, 'CA-0390000', 'Cetizine', '120(Tab)', 120000, 60000, '2023-07-25', NULL),
(43, 'CA-9990920', 'Acetaminophen', '200(Bot)', 1100000, 300000, '2023-08-07', NULL),
(44, 'CA-2000099', 'Flagyl,Pracetamol,Acetaminophen', '2(Bot),10(Bot),10(Bot)', 82000, 19000, '2023-08-07', NULL),
(45, 'CA-9020030', 'Acetaminophen,Fansidar,Coartem', '8(Bot),8(Bot),10(Bot)', 71000, 17100, '2023-08-08', NULL),
(46, 'CA-0203930', 'Cloxacillin', '9(Bot)', 11700, 1800, '2023-08-09', NULL),
(47, 'CA-9090202', 'Acetaminophen,Cloxacillin,Alinia', '2(Bot),1(Bot),2(Bot)', 26900, 4680, '2023-08-09', NULL),
(48, 'CA-0000002', 'Cloxacillin', '1(Bot)', 1300, 200, '2023-08-09', NULL),
(49, 'CA-0009030', 'Cloxacillin,Acetaminophen', '9(Bot),11(Bot)', 72200, 18300, '2023-08-09', NULL),
(50, 'CA-2929202', 'Cloxacillin', '5(Bot)', 6500, 1000, '2023-08-09', NULL),
(51, 'CA-0929320', 'Acetaminophen,Alinia,Coartem', '1(Bot),2(Bot),3(Bot)', 24600, 3790, '2023-08-09', NULL),
(52, 'CA-9090002', 'Coartem', '3(Bot)', 4500, 810, '2023-08-09', NULL),
(53, 'CA-0230930', 'Cloxacillin', '1(Bot)', 1300, 200, '2023-08-09', NULL),
(54, 'CA-2090203', 'Flagyl', '1(Bot)', 2000, 500, '2023-08-09', NULL),
(55, 'CA-9092002', 'Cloxacillin', '1(Bot)', 1300, 200, '2023-08-09', NULL),
(56, 'CA-0909003', 'Fansidar', '68(Bot)', 102000, 20400, '2023-08-10', NULL),
(57, 'CA-0992290', 'Acetaminophen', '1(Bot)', 5500, 1500, '2023-08-11', NULL),
(58, 'CA-9920000', 'Acetaminophen,Coartem', '1(Bot),1(Bot)', 7000, 1770, '2023-08-11', NULL),
(59, 'CA-9220029', 'Acetaminophen', '1(Bot)', 5500, 1500, '2023-08-11', 'mumbere'),
(60, 'CA-0000902', 'Fansidar', '2(Bot)', 3000, 600, '2023-08-11', 'PK'),
(61, 'CA-0202992', 'Pp', '', 0, 0, '2023-10-04', 'PK'),
(62, 'CA-9009020', 'Cetrizine', '', 0, 0, '2023-10-04', 'PK'),
(64, 'CA-2390030', 'Lydia post pill', '', 5000, 3400, '2023-10-30', 'PK'),
(65, 'CA-0220990', 'Rivotril', '', 5000, 2500, '2023-10-30', 'PK'),
(66, 'CA-2020990', 'Panadol extra', '', 2500, 1000, '2023-10-30', 'PK'),
(67, 'CA-0303990', 'Lydia post pill', '', 5000, 3400, '2023-10-30', 'PK'),
(68, 'CA-0003930', 'Recodin syrup', '', 6000, 2400, '2023-10-30', 'Audrey'),
(69, 'CA-0990009', 'Panadol extra', '', 2500, 1000, '2023-10-30', 'Audrey'),
(70, 'CA-0099039', 'Panadol extra', '', 1000, 400, '2023-10-30', 'Audrey'),
(71, 'CA-3299029', 'Dexona Ear-eye drop', '', 4000, 2350, '2023-10-30', 'Audrey'),
(72, 'CA-0309032', 'Flufed tbs', '', 2000, 1000, '2023-10-30', 'Audrey'),
(73, 'CA-0000000', 'Artesunate 120mg inj', '', 7000, 1900, '2023-10-30', 'Audrey'),
(74, 'CA-2230909', 'Rivotril', '', 10000, 5000, '2023-10-30', 'Audrey'),
(75, 'CA-9909902', 'Predsolone ', '', 1000, 500, '2023-10-30', 'Audrey'),
(76, 'CA-0999209', 'Tramadol capsule', '', 1000, 500, '2023-10-30', 'Audrey'),
(77, 'CA-0029303', 'Roxene 1gm ', '', 15000, 6500, '2023-10-30', 'Audrey'),
(78, 'CA-0090009', 'Artesunate 120mg inj', '', 7000, 1900, '2023-10-30', 'Audrey'),
(79, 'CA-0029090', 'Artesunate 60mg', '', 7000, 2000, '2023-10-30', 'Audrey'),
(80, 'CA-0930209', 'Coldcap', '', 3000, 1500, '2023-10-30', 'Audrey'),
(81, 'CA-3003902', 'Benzhexol', '', 2000, 1000, '2023-10-30', 'Audrey'),
(82, 'CA-9009099', 'Benzhexol', '', 2000, 1000, '2023-10-30', 'Audrey'),
(83, 'CA-0290090', 'Coldcap', '', 1800, 900, '2023-10-30', 'Audrey'),
(84, 'CA-2222009', 'Benzhexol', '', 2000, 1000, '2023-10-30', 'Audrey'),
(85, 'CA-0209099', 'Albendazole', '', 2000, 1000, '2023-10-30', 'Audrey'),
(86, 'CA-9090332', 'Paracetamol', '', 1000, 500, '2023-10-30', 'Audrey'),
(87, 'CA-0909900', 'Examination Gloves', '', 1000, 200, '2023-10-30', 'Audrey'),
(88, 'CA-0092902', 'Cough linctus,Amoxyl', '', 4500, 2000, '2023-10-30', 'Audrey'),
(89, 'CA-0902090', 'Piroxicam', '', 1000, 500, '2023-10-30', 'Audrey'),
(90, 'CA-0022329', 'Piroxicam', '', 1000, 500, '2023-10-30', 'Audrey'),
(91, 'CA-9029299', 'Piroxicam', '', 1000, 500, '2023-10-30', 'Audrey'),
(92, 'CA-0029200', 'Artesunate 120mg inj', '', 7000, 1900, '2023-10-30', 'Audrey'),
(93, 'CA-2002002', 'Toff plus,Ampiclox', '', 4500, 2250, '2023-10-30', 'Audrey'),
(94, 'CA-9203309', 'Metro tabs,Panadol extra,Piroxicam', '', 3000, 1400, '2023-10-30', 'Audrey'),
(95, 'CA-0200020', 'Ampiclox', '', 1000, 500, '2023-10-30', 'Audrey'),
(96, 'CA-9902229', 'Strepsils', '', 2000, 1200, '2023-10-30', 'Audrey'),
(97, 'CA-0320929', 'Zepar tablets', '', 3500, 1500, '2023-10-30', 'Audrey'),
(98, 'CA-0329200', 'Extradol,Sinarest', '', 2000, 1000, '2023-10-30', 'Audrey'),
(99, 'CA-3090002', 'Backup pill', '', 8000, 5400, '2023-10-30', 'Audrey'),
(100, 'CA-9009900', 'Backup pill', '', 8000, 5400, '2023-10-30', 'Audrey'),
(101, 'CA-0992000', 'Ampiclox', '', 2000, 1000, '2023-10-30', 'Audrey'),
(102, 'CA-0003030', 'Legnment ', '', 4000, 2000, '2023-10-30', 'Audrey'),
(103, 'CA-2290099', 'Surgical blade', '', 1000, 500, '2023-10-30', 'Audrey'),
(104, 'CA-2200039', 'Diazepam', '', 3000, 1500, '2023-10-30', 'Audrey'),
(105, 'CA-9090309', 'Cotton wool 100mg', '', 2000, 1000, '2023-10-30', 'Audrey'),
(106, 'CA-0900232', 'Phendabitol', '', 2000, 1000, '2023-10-30', 'Audrey'),
(107, 'CA-0900390', 'Surgical spirit', '', 4000, 2000, '2023-10-30', 'Audrey'),
(108, 'CA-9009209', 'Ma-kare,Metro tabs,Ibuprofen,Ampiclox', '', 59000, 36500, '2023-10-30', 'Audrey'),
(109, 'CA-0939002', 'HCG strip', '', 2000, 1200, '2023-10-30', 'Audrey'),
(110, 'CA-9999920', 'Ampicillin', '', 2000, 1200, '2023-10-30', 'Audrey'),
(111, 'CA-0000099', 'Loperamide', '', 1000, 200, '2023-10-30', 'Audrey'),
(112, 'CA-3099022', 'Recodin syrup', '', 6000, 2400, '2023-10-30', 'Audrey'),
(113, 'CA-0003900', 'Action tbs', '', 1000, 200, '2023-10-30', 'Audrey'),
(114, 'CA-9909990', 'Pen V (Unipen)', '', 1000, 750, '2023-10-30', 'Audrey'),
(115, 'CA-0990909', 'Sinarest', '', 1000, 500, '2023-10-30', 'Audrey'),
(116, 'CA-9230920', 'Unisten cream', '', 4000, 1500, '2023-10-30', 'Audrey'),
(117, 'CA-3092229', 'HCG strip', '', 2000, 1200, '2023-10-30', 'Audrey'),
(118, 'CA-0339920', 'Lydia post pill', '', 5000, 3400, '2023-10-30', 'Audrey'),
(119, 'CA-9390229', 'Lydia post pill', '', 5000, 3400, '2023-10-30', 'Audrey'),
(120, 'CA-2029922', 'Septrine 960mg', '', 1000, 500, '2023-10-30', 'Audrey'),
(121, 'CA-9930900', 'Tramadol capsule', '', 2000, 1000, '2023-10-30', 'Audrey'),
(122, 'CA-0029390', 'Misoclear,Metro tabs,Ibupar,Ampiclox', '', 58000, 31500, '2023-10-30', 'Audrey'),
(123, 'CA-0929330', 'Toractine syrup', '', 6000, 1800, '2023-10-30', 'Audrey'),
(124, 'CA-0200000', 'Action tbs', '', 1000, 200, '2023-10-30', 'Audrey'),
(125, 'CA-0922900', 'Mediven cream', '', 8000, 4000, '2023-10-30', 'Audrey'),
(126, 'CA-2900290', 'Toff plus', '', 2000, 1000, '2023-10-30', 'Audrey'),
(127, 'CA-2299002', 'Carbamezapine', '', 2000, 1000, '2023-10-30', 'Audrey'),
(128, 'CA-2999900', 'Painex', '', 1000, 500, '2023-10-30', 'Audrey'),
(129, 'CA-2320032', 'Lydia post pill', '', 5000, 3400, '2023-10-30', 'Audrey'),
(130, 'CA-9200992', 'Panadol advance', '', 2000, 1000, '2023-10-30', 'Audrey'),
(131, 'CA-0090929', 'Omperazole', '', 1000, 500, '2023-10-30', 'Audrey'),
(132, 'CA-0299090', 'Panadol extra', '', 1000, 400, '2023-10-30', 'Audrey'),
(133, 'CA-0300393', 'Sinarest', '', 1000, 500, '2023-10-30', 'Audrey'),
(134, 'CA-9393999', 'Tramadol capsule', '', 2000, 1000, '2023-10-30', 'Audrey'),
(135, 'CA-0932902', 'HCG strip', '', 2000, 1200, '2023-10-30', 'Audrey'),
(136, 'CA-2020209', 'Panadol extra', '', 1500, 600, '2023-10-30', 'Audrey'),
(137, 'CA-0222933', 'Kiss stawberry condom', '', 2000, 1200, '2023-10-30', 'Audrey'),
(138, 'CA-0900032', 'Kiss stawberry condom', '', 2000, 1200, '2023-10-30', 'Audrey'),
(139, 'CA-0003029', 'Menthxy longezes,Omeprazole', '', 3000, 1800, '2023-10-30', 'Audrey'),
(140, 'CA-0092900', 'MCG cream,Pirican', '', 7000, 2000, '2023-10-30', 'Audrey'),
(141, 'CA-9900999', 'Toff plus', '', 1000, 500, '2023-10-30', 'Audrey'),
(142, 'CA-0939009', 'P-Alaxin', '', 12000, 4800, '2023-10-30', 'Audrey'),
(143, 'CA-3339923', 'Lydia post pill', '', 10000, 6800, '2023-10-30', 'Audrey'),
(144, 'CA-2200923', 'Panadol extra', '', 1000, 400, '2023-10-30', 'Audrey'),
(145, 'CA-0922220', 'Lydia post pill', '', 5000, 3400, '2023-10-30', 'Audrey'),
(146, 'CA-0929229', 'Nasatab tbs', '', 5000, 3000, '2023-10-30', 'Audrey'),
(147, 'CA-9003039', 'Biscodyl,Panadol extra', '', 3500, 1500, '2023-10-30', 'Audrey'),
(148, 'CA-0000009', 'Chlerphemin', '', 500, 300, '2023-10-30', 'Audrey');

-- --------------------------------------------------------

--
-- Table structure for table `stock`
--

CREATE TABLE `stock` (
  `id` int(100) NOT NULL,
  `bar_code` varchar(255) NOT NULL,
  `medicine_name` varchar(100) NOT NULL,
  `category` varchar(100) NOT NULL,
  `quantity` int(100) NOT NULL,
  `used_quantity` int(100) NOT NULL,
  `remain_quantity` int(100) NOT NULL,
  `act_remain_quantity` int(10) NOT NULL,
  `register_date` date NOT NULL,
  `expire_date` date NOT NULL,
  `company` varchar(100) NOT NULL,
  `sell_type` varchar(100) NOT NULL,
  `actual_price` int(100) NOT NULL,
  `selling_price` int(100) NOT NULL,
  `profit_price` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `stock`
--

INSERT INTO `stock` (`id`, `bar_code`, `medicine_name`, `category`, `quantity`, `used_quantity`, `remain_quantity`, `act_remain_quantity`, `register_date`, `expire_date`, `company`, `sell_type`, `actual_price`, `selling_price`, `profit_price`, `status`) VALUES
(1, 'JCFB0031', 'Jenacof SD sysp', '200ml', 2, 0, 2, 2, '2023-10-30', '2025-04-30', '', 'Bot', 3900, 6000, '2100(54%)', 'Available'),
(2, '0723', 'Flufed tbs', 'Tbs', 100, 10, 90, 90, '2023-10-30', '2024-04-30', '', 'Tab', 100, 200, '100(100%)', 'Available'),
(3, 'CF8450722', 'Coldease cps', 'Cps', 100, 0, 100, 100, '2023-10-30', '2025-06-30', '', 'Tab', 100, 200, '100(100%)', 'Available'),
(4, '230305', 'Cetamol syrup', 'Sys', 2, 0, 2, 2, '2023-10-30', '2026-01-31', '', 'Bot', 3200, 6000, '2800(88%)', 'Available'),
(5, 'PC1923', 'Piritex codain', 'Sysp', 2, 0, 2, 2, '2023-10-30', '2026-06-30', '', 'Bot', 5600, 7000, '1400(25%)', 'Available'),
(6, '21sdd', 'P-Alaxin', ' 40mg/320mg', 2, 1, 1, 1, '2023-10-30', '2028-12-31', '', 'Bot', 7200, 12000, '4800(67%)', 'Available'),
(7, '1853', 'Lydia post pill', '1.5mg', 10, 8, 2, 2, '2023-10-30', '2025-02-28', '', 'Bot', 1600, 5000, '3400(213%)', 'Available'),
(8, '68E01122', 'Dexona Ear-eye drop', 'Cadilla', 2, 1, 1, 1, '2023-10-30', '2025-04-30', '', 'Bot', 1650, 4000, '2350(142%)', 'Available'),
(9, 'UG203212', 'Metro IV', '100ml', 5, 0, 5, 5, '2023-10-30', '2025-12-31', '', 'Bot', 1240, 6200, '4960(400%)', 'Available'),
(10, 'PA07622', 'AzithroTab 500mg ZAHA', '500mg', 3, 0, 3, 3, '2023-10-30', '2024-06-30', '', 'Bot', 4500, 7000, '2500(56%)', 'Available'),
(11, 'B2302017', 'Nasatab tbs', 'Tbs', 100, 10, 90, 90, '2023-10-30', '2026-02-28', '', 'Bot', 200, 500, '300(150%)', 'Available'),
(12, '1', 'Predsolone ', 'Tabs', 100, 10, 90, 90, '2023-10-30', '2025-12-31', '', 'Tab', 50, 100, '50(100%)', 'Available'),
(13, '004224', 'Ibuprofen', 'Tbs', 100, 20, 80, 100, '2023-10-30', '2025-12-31', '', 'Bot', 50, 100, '50(100%)', 'Available'),
(14, 'BZN-22019', 'Zyncet /cetrizine', 'Tbs', 50, 0, 50, 50, '2023-10-30', '2025-05-31', '', 'Bot', 50, 100, '50(100%)', 'Available'),
(15, '54ER2VC', 'Para-Denk', 'Suppos', 10, 0, 10, 10, '2023-10-30', '2028-12-31', '', 'Bot', 9200, 12000, '2800(30%)', 'Available'),
(16, 'PCTM22', 'Typhoid strip', 'Strip', 20, 0, 20, 20, '2023-10-30', '2024-11-30', '', 'Bot', 1550, 5000, '3450(223%)', 'Available'),
(17, '230491', 'Sediproct supp', 'Supp', 1, 0, 1, 1, '2023-10-30', '2026-02-28', '', 'Bot', 7500, 12000, '4500(60%)', 'Available'),
(18, 'IP23021', 'Artesunate 120mg inj', 'Royal', 5, 3, 2, 2, '2023-10-30', '2025-01-31', '', 'Bot', 5100, 7000, '1900(37%)', 'Available'),
(19, 'J3AAV0018', 'Rexone ceftriaxone 1.5g', 'Sulb', 5, 0, 5, 5, '2023-10-30', '2026-06-30', '', 'Bot', 2600, 5000, '2400(92%)', 'Available'),
(20, '1343Z078', 'Roxene 1gm ', 'Cef', 16, 10, 6, 6, '2023-10-30', '2026-02-28', '', 'Bot', 850, 1500, '650(76%)', 'Available'),
(21, 'AB209', 'Aciclovir cream', '10gm', 4, 0, 4, 4, '2023-10-30', '2025-10-31', '', 'Bot', 1300, 5000, '3700(285%)', 'Available'),
(22, '221126', 'Creep bandage 15cm', '15cm', 4, 0, 4, 4, '2023-10-30', '2027-11-30', '', 'Bot', 1300, 2000, '700(54%)', 'Available'),
(23, '587', 'Metformin denk', '500mg', 100, 0, 100, 100, '2023-10-30', '2025-12-31', '', 'Bot', 1000, 1300, '300(30%)', 'Available'),
(24, '0823', 'Amoxykid', '125 kid tab', 1, 0, 1, 1, '2023-10-30', '2025-05-31', '', 'Bot', 4900, 6000, '1100(22%)', 'Available'),
(25, '226930', 'Nueroton ', 'Tbs', 20, 0, 20, 20, '2023-10-30', '2024-11-30', '', 'Bot', 200, 500, '300(150%)', 'Available'),
(26, '5554', 'Postinor-2', 'Tab', 2, 0, 2, 2, '2023-10-30', '2025-12-31', '', 'Bot', 7400, 13000, '5600(76%)', 'Available'),
(27, 'Y082ZD', 'Panadol extra', 'Tbs', 100, 52, 48, 58, '2023-10-30', '2025-03-31', '', 'Bot', 150, 250, '100(67%)', 'Available'),
(28, '2211005', 'Action tbs', 'Tbs', 100, 8, 92, 92, '2023-10-30', '2027-10-31', '', 'Bot', 200, 250, '50(25%)', 'Available'),
(29, '2211195', 'Curamol plus', 'Tbs', 100, 0, 100, 100, '2023-10-30', '2025-10-31', '', 'Bot', 250, 500, '250(100%)', 'Available'),
(30, '230523', 'Duo-cotecxin', 'Tbs', 9, 0, 9, 9, '2023-10-30', '2025-05-31', '', 'Bot', 1000, 2000, '1000(100%)', 'Available'),
(31, 'FCL23002', 'Flucap syrup', '100ml', 2, 0, 2, 2, '2023-10-30', '2026-01-31', '', 'Bot', 3600, 8000, '4400(122%)', 'Available'),
(32, '00723', 'Recodin syrup', '100ml', 3, 2, 1, 1, '2023-10-30', '2025-06-30', '', 'Bot', 3600, 6000, '2400(67%)', 'Available'),
(33, '10222791', 'Acsoril syrup', 'Sysp', 2, 0, 2, 2, '2023-10-30', '2024-10-31', '', 'Bot', 5900, 7000, '1100(19%)', 'Available'),
(34, 'DXT062204', 'Dexariv tbs', '0.5mg', 100, 0, 100, 100, '2023-10-30', '2025-05-31', '', 'Bot', 180, 500, '320(178%)', 'Available'),
(35, 'DR101', 'Deep ruby rollon', '10ml', 2, 0, 2, 2, '2023-10-30', '2025-08-31', '', 'Bot', 2600, 5000, '2400(92%)', 'Available'),
(36, 'D181518', 'Cozepam', '5mg', 100, 0, 100, 100, '2023-10-30', '2027-02-28', '', 'Bot', 100, 200, '100(100%)', 'Available'),
(37, '05723', 'Umpclox', 'Cap', 100, 0, 100, 100, '2023-10-30', '2025-05-31', '', 'Bot', 100, 200, '100(100%)', 'Available'),
(38, 'PA18582', 'Apcalis SX', '20mg', 4, 0, 4, 4, '2023-10-30', '2025-10-30', '', 'Bot', 3200, 7000, '3800(119%)', 'Available'),
(39, 'PA18582', 'Apcalis SX', '20mg', 4, 0, 4, 4, '2023-10-30', '2025-10-30', '', 'Bot', 3200, 7000, '3800(119%)', 'Available'),
(40, '1HABW001', 'Monticope', 'Tabs', 30, 0, 30, 30, '2023-10-30', '2025-12-31', '', 'Bot', 250, 500, '250(100%)', 'Available'),
(41, '23XNMS080', 'Neutroflux sysp', '200ml', 1, 0, 1, 1, '2023-10-30', '2026-01-31', '', 'Bot', 8700, 12000, '3300(38%)', 'Available'),
(42, '17100672', 'Normal saline', 'Abaris', 16, 0, 16, 16, '2023-10-30', '2025-08-31', '', 'Bot', 1850, 2500, '650(35%)', 'Available'),
(43, 'ESS1GTA170', 'Clomiphene/Romiphene', 'Tbs', 10, 0, 10, 10, '2023-10-30', '2025-11-30', '', 'Bot', 8600, 12000, '3400(40%)', 'Available'),
(45, '10231422', 'Candiderm cream', '15gm', 2, 0, 2, 2, '2023-10-30', '2026-04-30', '', 'Bot', 4700, 6000, '1300(28%)', 'Available'),
(46, '58778', 'Ringers lactate', '500ml', 15, 0, 15, 15, '2023-10-30', '2025-12-31', '', 'Bot', 1850, 2500, '650(35%)', 'Available'),
(47, 'FZC122202', 'Fluconazole ', '200mg', 40, 0, 40, 40, '2023-10-30', '2025-11-30', '', 'Bot', 460, 1000, '540(117%)', 'Available'),
(48, '123TYT6', 'Levofloxacin', '500mg', 40, 0, 40, 40, '2023-10-30', '2025-12-31', '', 'Bot', 220, 1000, '780(355%)', 'Available'),
(49, '2122', 'Erythromycin tabs', '250mg', 100, 0, 100, 100, '2023-10-30', '2025-01-31', '', 'Bot', 50, 100, '50(100%)', 'Available'),
(50, '22SKN', 'Skin balance', 'Gel', 1, 0, 1, 1, '2023-10-30', '2025-01-31', '', 'Bot', 4300, 6000, '1700(40%)', 'Available'),
(51, '0523005J', 'Calamine lotion', '100ml', 2, 0, 2, 2, '2023-10-30', '2025-01-31', '', 'Bot', 2000, 4000, '2000(100%)', 'Available'),
(52, '2204993716', 'Skin condom', 'Cd', 2, 0, 2, 2, '2023-10-30', '2027-03-31', '', 'Bot', 10000, 15000, '5000(50%)', 'Available'),
(53, '22N1230', 'O condom ', 'Cd', 4, 0, 4, 4, '2023-10-30', '2027-04-30', '', 'Bot', 1200, 3000, '1800(150%)', 'Available'),
(54, '372107', 'Duphaston tabs', '10mg', 20, 0, 20, 20, '2023-10-30', '2028-06-30', '', 'Bot', 1200, 2000, '800(67%)', 'Available'),
(55, 'FW047H', 'Probeta N eye drops', '7.5ml', 3, 0, 3, 3, '2023-10-30', '2024-04-30', '', 'Bot', 3600, 6000, '2400(67%)', 'Available'),
(56, '23IVCE', 'Yellow cannular', 'IV', 100, 0, 100, 100, '2023-10-30', '2028-04-30', '', 'Bot', 340, 1000, '660(194%)', 'Available'),
(57, 'RISL23001', 'Tramadol capsule', 'Tabs', 200, 25, 175, 175, '2023-10-30', '2028-10-31', '', 'Bot', 100, 200, '100(100%)', 'Available'),
(58, 'LOR131', 'Lonart 20mg', 'Tabs', 5, 0, 5, 5, '2023-10-30', '2024-01-31', '', 'Bot', 2200, 5000, '2800(127%)', 'Available'),
(59, 'PJP123', 'Piritex Junior syrup', 'Susp', 2, 0, 2, 2, '2023-10-30', '2026-02-28', '', 'Bot', 3150, 5000, '1850(59%)', 'Available'),
(60, 'C24012', 'Agoplus capsules', 'Tabs', 20, 0, 20, 20, '2023-10-30', '2025-06-30', '', 'Bot', 250, 500, '250(100%)', 'Available'),
(61, '8354C', 'Cough linctus', '200ml', 4, 0, 4, 4, '2023-10-30', '2025-12-31', '', 'Bot', 2100, 5000, '2900(138%)', 'Available'),
(62, '6635S', 'Centipar syrup', '30ml', 2, 0, 2, 2, '2023-10-30', '2025-12-31', '', 'Bot', 2250, 5000, '2750(122%)', 'Available'),
(63, '142XP', 'Zepar syrup', 'Supp', 3, 0, 3, 3, '2023-10-30', '2025-10-31', '', 'Bot', 2300, 5000, '2700(117%)', 'Available'),
(64, '2K30A1', 'Gofen ', '400mg', 60, 0, 60, 60, '2023-10-30', '2024-11-30', '', 'Bot', 400, 1000, '600(150%)', 'Available'),
(65, '223388T', 'Normal saline nasal', 'Nasal drop', 8, 0, 8, 8, '2023-10-30', '2025-01-31', '', 'Bot', 1650, 2500, '850(52%)', 'Available'),
(66, '5887PA', 'Panadol advance', 'Tabs', 100, 10, 90, 90, '2023-10-30', '2025-12-31', '', 'Bot', 100, 200, '100(100%)', 'Available'),
(67, '2217UN', 'Pen V (Unipen)', 'Tabs', 100, 5, 95, 95, '2023-10-30', '2025-08-31', '', 'Bot', 50, 200, '150(300%)', 'Available'),
(68, '04323S', 'Semtrim', 'Tab', 100, 0, 100, 100, '2023-10-30', '2026-04-30', '', 'Bot', 50, 100, '50(100%)', 'Available'),
(69, 'XT2K101', 'Tinidazole', 'Tabs', 100, 0, 100, 100, '2023-10-30', '2025-10-31', '', 'Bot', 50, 100, '50(100%)', 'Available'),
(70, 'EUGWE21003', 'Levocetrizine', 'Tbs', 100, 0, 100, 100, '2023-10-30', '2025-09-30', '', 'Bot', 100, 200, '100(100%)', 'Available'),
(71, '0223DSAL', 'Salbutamol', 'Tbs', 100, 0, 100, 100, '2023-10-30', '2025-03-31', '', 'Bot', 80, 100, '20(25%)', 'Available'),
(72, 'OMEP34', 'Omeprazole', 'Tabs', 200, 15, 185, 195, '2023-10-30', '2025-12-31', '', 'Bot', 100, 200, '100(100%)', 'Available'),
(73, '456TG6\r\n', 'Candid V gel', '30mg', 2, 0, 2, 2, '2023-10-30', '2025-08-31', '', 'Tube', 7200, 10000, '2800(39%)', 'Available'),
(74, '211202', 'Adhensive plaster', 'Plaster', 3, 0, 3, 3, '2023-10-30', '2026-12-31', '', 'Bot', 1500, 2000, '500(33%)', 'Available'),
(75, '10123026', 'Ceftriaxone  Zefone', 'Cadilla 1g', 10, 0, 10, 10, '2023-10-30', '2026-02-28', '', 'Bot', 2500, 3000, '500(20%)', 'Available'),
(76, 'XD3C004', 'Artesunate 60mg', 'Injection', 10, 2, 8, 8, '2023-10-30', '2026-02-28', '', 'Bot', 2500, 3500, '1000(40%)', 'Available'),
(77, 'L19221105', 'Kiss classic condom', 'Cd', 24, 0, 24, 24, '2023-10-30', '2027-08-31', '', 'Bot', 800, 2000, '1200(150%)', 'Available'),
(78, 'XA3F011', 'Gentamycin inj', '2ml', 20, 0, 20, 20, '2023-10-30', '2026-12-31', '', 'Bot', 450, 1000, '550(122%)', 'Available'),
(79, 'IBU132', 'Ibupar', 'Tabs', 100, 10, 90, 100, '2023-10-30', '2025-12-31', '', 'Bot', 50, 100, '50(100%)', 'Available'),
(80, 'KAM12', 'Kamagra 100mg', '100mg', 4, 0, 4, 4, '2023-10-30', '2024-12-31', '', 'Bot', 3500, 5000, '1500(43%)', 'Available'),
(81, 'RIV1234', 'Rivotril', 'Tabs', 40, 15, 25, 25, '2023-10-30', '2026-01-30', '', 'Tab', 500, 1000, '500(100%)', 'Available'),
(82, 'DD3002', 'Ofloxacin', 'Tabs', 100, 0, 100, 100, '2023-10-30', '2026-01-30', '', 'Bot', 50, 100, '50(100%)', 'Available'),
(83, 'COL123', 'Coldcap', 'Tabs', 100, 16, 84, 84, '2023-10-30', '2025-10-30', '', 'Bot', 150, 300, '150(100%)', 'Available'),
(84, 'BEN234L', 'Benzhexol', 'Tabs', 100, 30, 70, 70, '2023-10-30', '2026-10-30', '', 'Bot', 100, 200, '100(100%)', 'Available'),
(85, 'ALB17N', 'Albendazole', 'Tabs', 20, 1, 19, 19, '2023-10-30', '2025-10-30', '', 'Bot', 1000, 2000, '1000(100%)', 'Available'),
(86, 'KKJ10L', 'Paracetamol', 'Tabs', 500, 10, 490, 490, '2023-10-30', '2026-03-13', '', 'Bot', 50, 100, '50(100%)', 'Available'),
(87, 'VGL098', 'Examination Gloves', 'Medical', 150, 1, 149, 149, '2023-10-30', '2025-01-31', '', 'Bot', 800, 1000, '200(25%)', 'Available'),
(88, 'K12006', 'Agovate', 'Cream', 3, 0, 3, 3, '2023-10-30', '2024-03-30', '', 'Tube', 2500, 4000, '1500(60%)', 'Available'),
(89, '0120001', 'Agocort skin ointment', 'Cream', 1, 0, 1, 1, '2023-10-30', '2024-03-30', '', 'Bot', 2500, 4000, '1500(60%)', 'Available'),
(90, '230955', 'Unisten cream', 'Cream', 4, 1, 3, 3, '2023-10-30', '2026-04-30', '', 'Bot', 2500, 4000, '1500(60%)', 'Available'),
(91, 'KBF151', 'Funbact-A', 'Cream', 2, 0, 2, 2, '2023-10-30', '2026-05-30', '', 'Bot', 2500, 4000, '1500(60%)', 'Available'),
(92, '93087', 'Ketoconazole', 'Tables', 100, 0, 100, 100, '2023-10-30', '2026-02-28', '', 'Bot', 500, 700, '200(40%)', 'Available'),
(93, '99163', 'Griseofulvin', 'Tabs', 100, 0, 100, 100, '2023-10-30', '2027-01-31', '', 'Bot', 500, 700, '200(40%)', 'Available'),
(94, 'T33012', 'Agofulvin', '500mg', 200, 0, 200, 200, '2023-10-30', '2026-04-30', '', 'Bot', 550, 700, '150(27%)', 'Available'),
(95, 'AMX12', 'Amoxyl', 'Tabs', 300, 20, 280, 300, '2023-10-30', '2025-10-30', '', 'Bot', 50, 100, '50(100%)', 'Available'),
(96, 'COU65', 'Cough linctus', 'Sys', 10, 1, 9, 9, '2023-10-30', '2025-10-31', '', 'Bot', 1500, 3500, '2000(133%)', 'Available'),
(97, 'PIRO98', 'Piroxicam', 'Tabs', 200, 40, 160, 170, '2023-10-30', '2025-10-30', '', 'Bot', 50, 100, '50(100%)', 'Available'),
(98, '12L89', 'Ampiclox', 'Tabs', 200, 65, 135, 175, '2023-10-30', '2026-01-31', '', 'Bot', 100, 200, '100(100%)', 'Available'),
(99, 'UG5647', 'Toff plus', 'Tabs', 40, 11, 29, 29, '2023-10-30', '2025-06-30', '', 'Bot', 250, 500, '250(100%)', 'Available'),
(100, '12GY67', 'Metro tabs', 'Cps', 500, 70, 430, 490, '2023-10-30', '2026-04-30', '', 'Bot', 50, 100, '50(100%)', 'Available'),
(101, '2S1P1100', 'Strepsils', 'Tabs', 200, 4, 196, 196, '2023-10-30', '2025-02-28', '', 'Bot', 200, 500, '300(150%)', 'Available'),
(102, 'ZPR22', 'Zepar tablets', 'Tabs', 10, 1, 9, 9, '2023-10-30', '2026-12-31', '', 'Bot', 2000, 3500, '1500(75%)', 'Available'),
(103, 'SIN707', 'Sinarest', 'Tabs', 50, 3, 47, 47, '2023-10-30', '2026-12-31', '', 'Bot', 500, 1000, '500(100%)', 'Available'),
(104, 'DOL78', 'Extradol', 'Tabs', 100, 2, 98, 98, '2023-10-30', '2025-12-31', '', 'Bot', 250, 500, '250(100%)', 'Available'),
(105, 'BACH89', 'Backup pill', 'Pill', 10, 2, 8, 8, '2023-10-30', '2027-03-12', '', 'Bot', 2600, 8000, '5400(208%)', 'Available'),
(106, 'LIN33', 'Legnment ', 'Spray', 3, 1, 2, 2, '2023-10-30', '2025-01-31', '', 'Bot', 2000, 4000, '2000(100%)', 'Available'),
(107, 'sug98', 'Surgical blade', 'Lade', 30, 1, 29, 29, '2023-10-30', '2025-10-30', '', 'Bot', 500, 1000, '500(100%)', 'Available'),
(108, 'DAZ67KI', 'Diazepam', 'Tabs', 100, 10, 90, 90, '2023-10-30', '2025-10-30', '', 'Bot', 150, 300, '150(100%)', 'Available'),
(109, 'W009OLK', 'Cotton wool 100mg', '100mg', 5, 1, 4, 4, '2023-10-30', '2026-11-30', '', 'Bot', 1000, 2000, '1000(100%)', 'Available'),
(110, '12P87', 'Phendabitol', 'Tabs', 250, 10, 240, 240, '2023-10-30', '2026-10-30', '', 'Bot', 100, 200, '100(100%)', 'Available'),
(111, 'SP7TYG', 'Surgical spirit', 'Spirit', 2, 1, 1, 1, '2023-10-30', '2024-09-30', '', 'Bot', 2000, 4000, '2000(100%)', 'Available'),
(112, 'MAK45RE', 'Ma-kare', 'Tabs', 5, 1, 4, 4, '2023-10-30', '2025-10-30', '', 'Bot', 18000, 50000, '32000(178%)', 'Available'),
(113, 'HC6679', 'HCG strip', 'Strip', 200, 3, 197, 197, '2023-10-30', '2027-02-28', '', 'Bot', 800, 2000, '1200(150%)', 'Available'),
(114, '12990Y', 'Ampicillin', 'Tabs', 200, 10, 190, 190, '2023-10-30', '2025-10-30', '', 'Bot', 80, 200, '120(150%)', 'Available'),
(115, '0696LoP', 'Loperamide', 'Tbs', 200, 10, 190, 190, '2023-10-30', '2026-10-30', '', 'Bot', 80, 100, '20(25%)', 'Available'),
(116, 'CTX960', 'Septrine 960mg', 'Tabs', 200, 5, 195, 195, '2023-10-30', '2026-02-08', '', 'Bot', 100, 200, '100(100%)', 'Available'),
(117, 'TBSC78', 'Misoclear', 'Tabs', 20, 5, 15, 15, '2023-10-30', '2025-02-28', '', 'Bot', 4500, 10000, '5500(122%)', 'Available'),
(118, '098997Y', 'Toractine syrup', 'Syp', 3, 1, 2, 2, '2023-10-30', '2025-02-28', '', 'Bot', 4200, 6000, '1800(43%)', 'Available'),
(119, '88799T', 'Mediven cream', 'Cream', 3, 2, 1, 1, '2023-10-30', '2025-03-13', '', 'Bot', 2000, 4000, '2000(100%)', 'Available'),
(120, 'T78TY', 'Carbamezapine', 'Tbs', 200, 10, 190, 190, '2023-10-30', '2027-12-31', '', 'Bot', 100, 200, '100(100%)', 'Available'),
(121, '223388T6', 'Painex', 'Tbs', 100, 2, 98, 98, '2023-10-30', '2025-12-31', '', 'Bot', 250, 500, '250(100%)', 'Available'),
(122, 'LL12345', 'Kiss stawberry condom', 'Pac', 24, 2, 22, 22, '2023-10-30', '2026-11-30', '', 'Bot', 800, 2000, '1200(150%)', 'Available'),
(123, 'NTY76', 'Menthxy longezes', 'Pck', 10, 2, 8, 8, '2023-10-30', '2026-11-30', '', 'Bot', 100, 500, '400(400%)', 'Available'),
(124, 'YU787U', 'MCG cream', 'Cream', 2, 1, 1, 1, '2023-10-30', '2025-12-31', '', 'Bot', 4500, 6000, '1500(33%)', 'Available'),
(125, '9977U7', 'Pirican', 'Tabs', 100, 10, 90, 100, '2023-10-30', '2024-02-28', '', 'Bot', 50, 100, '50(100%)', 'Available'),
(126, '9988778', 'Biscodyl', 'Tbs', 100, 10, 90, 90, '2023-10-30', '2027-06-30', '', 'Bot', 50, 100, '50(100%)', 'Available'),
(127, 'BUTYHT7', 'Chlerphemin', 'Tbs', 20, 1, 19, 19, '2023-10-30', '2026-05-30', '', 'Bot', 200, 500, '300(150%)', 'Available'),
(128, '3176874', 'Zinc picolinate', 'Tabs', 7, 0, 7, 7, '2023-10-30', '2023-09-30', 'Expired', 'Bot', 1000, 2000, '1000(100%)', 'Available'),
(129, 'W946', 'Atoxia 120mg', 'Eloricoxib', 14, 0, 14, 14, '2023-10-30', '2023-08-31', 'Expired', 'Bot', 4500, 6500, '2000(44%)', 'Available');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `user_name`, `password`) VALUES
(1, 'admin', '6812f136d636e737248d365016f8cfd5139e387c');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `on_hold`
--
ALTER TABLE `on_hold`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pharmacist`
--
ALTER TABLE `pharmacist`
  ADD PRIMARY KEY (`pharmacist_id`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stock`
--
ALTER TABLE `stock`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `on_hold`
--
ALTER TABLE `on_hold`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=261;

--
-- AUTO_INCREMENT for table `pharmacist`
--
ALTER TABLE `pharmacist`
  MODIFY `pharmacist_id` tinyint(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=149;

--
-- AUTO_INCREMENT for table `stock`
--
ALTER TABLE `stock`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=130;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
